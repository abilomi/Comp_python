movie_count = [3,5,10,7,4]
#box operator 
print("=======================================")



for i in range(0,len(movie_count)): 
	if movie_count[i] > 4:
		print ("you watched a lot of movies!")
	else:
		print("you watched few movies...")
