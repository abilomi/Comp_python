#we use input funcion with the "prompt"
#to get user's name
#save the name in a variable 
name = input("what's your name?")
print("Hi", name)

call = input("who do you lke to call Abi")
print("can you please call")