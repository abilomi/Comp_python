green_tea = 3
sushi_plates = 10

price_1 = 2.50
price_2 = 1.50

print(green_tea * price_1)
print(sushi_plates * price_2)

