 
movie_count = 2
 
if movie_count > 4:
	print ("you watched a lot of movies!")
else:
	print("you watched few movies...")
	