Countries = ["USA", "Ethiopia", "Canada", "France", "Mexico"]
print(Countries[4])#print only the 5 item 
for f in Countries: #print the entire list 
	print(f)
print(Countries)
